<?php

namespace Hihi\Baithithu\models;

class Teacher extends BaseModel
{
    function getListTeacher() {
        $sql = "SELECT * FROM `teacher`";
        return $this->loadAllRows([],$sql);
    }
    function postTeacher($name,$email,$salary, $school){
        $sql = "INSERT INTO `teacher` ( `name`, `email`, `salary`, `school`) VALUES ( '{$name}', '{$email}', '{$salary}', '{$school}')";
    $sql= $this->execute([],$sql);
    }
    function  deleteTeacher($id) {
       $sql="DELETE FROM `teacher` WHERE id = " .$id;
       return $this->execute([],$sql);
   }
    function getEdit($id){
        $sql = "SELECT * FROM teacher WHERE id = " . $id;
        return $this->loadRow([],$sql);
    }
    function Edit($id,$name,$email,$salary, $school){
        $sql = "UPDATE `teacher` SET `name`='{$name}',`email`='{$email}',`salary`='{$salary}',`school`='{$school}' WHERE id =" . $id;
        return $this->execute([],$sql);
    }
            
}