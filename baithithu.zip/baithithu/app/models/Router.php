<?php

namespace Hihi\Baithithu\Models;

class Router
{
    public $routes = [];

    public function setRoute($url, $action)
    {
        $this->routes[$url] = $action;
    }

    public function get($url, $action)
    {
        $this->routes[$url]['GET'] = $action;
    }

    public function post($url, $action)
    {
        $this->routes[$url]['POST'] = $action;
    }

    public function handleRoute($url, $method)
    {
        if (isset($this->routes[$url][$method])){
            $handle = $this->routes[$url][$method];
            // thuc thi function handle
            if (is_callable($handle)){
                $handle();
            }else echo '404 Not Found Function';
        }else {
            echo '404 Not Found';
        }

    }
}
