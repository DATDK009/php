<?php
namespace Hihi\Baithithu\controllers;

    // Define the interface
    interface ControllerInterface {
        public function getTeacher();
        public function showTeacher();
        public function addTeachers();
        public function showEdit();
        public function EditT();
        public function delete();
        
    }
?>