<?php
namespace Hihi\Baithithu\controllers;
use Hihi\Baithithu\models\Teacher;
use Hihi\Baithithu\controllers\ControllerInterface;
class TeacherController extends BaseController implements ControllerInterface
{
    public function getTeacher() {
        $teacher = new Teacher();
        $teachers = $teacher->getListTeacher();
        return $this->render('teacher.index',compact('teachers'));
    }
    public function  showTeacher() {
        $teacher = new Teacher();
        $teacher = $teacher->getListTeacher();
        return $this->render('teacher.add',compact('teacher'));
    }
    public function addTeachers(){
        
        if (isset($_POST['btn_sub'])) {
            //Kiểm tra dữ liệu nhập vào
            // if (!isset($_POST['name']) || !isset($_POST['email'])) {
            //     die("Vui lòng nhập đủ thông tin");
            // }
            $name = $_POST["name"];
            $email = $_POST["email"];
            $salary = $_POST["salary"];
            $school = $_POST["school"];
            //Thêm mới giáo viên
            $teacher = new Teacher();
            $teacher -> postTeacher($name,$email,$salary, $school);
            header('location:index.php?url=listTeacher');
        }
    }

    public function showEdit(){
        if(isset($_GET['id'])) {
            $id=$_GET['id'];
            $teacher=new Teacher();
            $data=$teacher->getEdit($id);
            return $this->render('teacher.edit',compact('data'));
        }
    }
    public function EditT(){
        if(isset($_POST['btn_edit'])) {
            $id= $_POST['id'];
            $name = $_POST["name"];
            $email = $_POST["email"];
            $salary = $_POST["salary"];
            $school = $_POST["school"];
            $teacher=new Teacher();
            $teacher->Edit($id,$name ,$email ,$salary,$school);
            header('Location: index.php?url=listTeacher');
        }
    }
    public function delete() {
        $id = $_GET['id'];
        $teacher = new Teacher();
        $result = $teacher->deleteTeacher($id);
        header('location:index.php?url=listTeacher');
    }
    
}
