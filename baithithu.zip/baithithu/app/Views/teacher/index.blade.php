@extends('layout.main')
@section('content')
<script>
    function confirmDelete(id) {
        var result = confirm("Bạn có chắc chắn muốn xóa?");
        if (result) {
            window.location.href = "./index.php?url=delete&id=" + id;
        }
    }
</script>

<table border="1">
    <thead>
        <th>ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Salary</th>
        <th>School</th>
        <th>Action</th>
    </thead>
    <tbody>
         @foreach($teachers as $c)
            <tr>
                <td>{{ $c->id }}</td>
                <td>{{ $c->name }}</td>
                <td>{{ $c->email }}</td>
                <td>{{ $c->salary }}</td>
                <td>{{ $c->school }}</td>
                <th>
                    <a href="./index.php?url=showEdit&id={{ $c->id }}">Sửa</a>
                    <a href="javascript:void(0);" onclick="confirmDelete({{ $c->id }})">Xóa</a>
                </th>
            </tr>
        @endforeach
    </tbody>
</table>
@endsection
