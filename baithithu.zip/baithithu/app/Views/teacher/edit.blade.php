@extends('layout.main')
@section('content')
<form action="index.php?url=EditT" method="post">
    <input type="hidden" name="id" value="{{$data->id}}"/>
    <label for="">Nhập tên</label>
    <input type="text"  name="name" id="" placeholder="Tên người dùng" value="{{$data->name}}" required ><br><br>
    <label for="">Nhập email</label>
    <input type="email" name="email" id="" placeholder="Email của bạn" value="{{$data->email}}" required><br><br>
    <label for="">Nhập lương</label>
    <input type="number" name="salary" id="" placeholder="Lương của bạn" value="{{$data->salary}}"required ><br><br>
    <label for="">Nhập trường</label>
    <input type="text" name="school" placeholder="Trường của bạn" value="{{$data->school}}"required ><br><br>
    <button type="submit" name="btn_edit">Cập nhập</button>
</form>
</table>
@endsection