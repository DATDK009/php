@extends('layout.main')
@section('content')
<form action="index.php?url=addTeachers" method="post" >
    <label for="">Nhập tên</label>
    <input type="text"  name="name" id=""required placeholder="Tên người dùng"><br><br>
    <label for="">Nhập email</label>
    <input type="email" name="email" id=""required placeholder="Email của bạn"><br><br>
    <label for="">Nhập lương</label>
    <input type="number" name="salary" id=""required placeholder="Lương của bạn" ><br><br>
    <label for="">Nhập trường</label>
    <input type="text" name="school" placeholder="Trường của bạn" required ><br><br>
    <button type="submit" name="btn_sub">Thêm mới</button>
</form>
</table>
@endsection