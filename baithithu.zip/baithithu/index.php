<?php
require './vendor/autoload.php';

use Hihi\Baithithu\models\Router;
use Hihi\Baithithu\controllers\TeacherController;

$router = new Router();
$router->get('listTeacher', [new TeacherController(), 'getTeacher']);
$router->get('showTeacher', [new TeacherController(),'showTeacher']);
$router->post('addTeachers', [new TeacherController(), 'addTeachers']);
$router->get('showEdit', [new TeacherController(),'showEdit']);
$router->post('EditT',[new TeacherController(),'EditT'] );
$router->get('delete', [new TeacherController(),'delete']);


// $router->get('/', function () { return 'Hello World!'; });

if (isset($_GET['url'])) {
    $url = $_GET['url'];
} else {
    $url = './index.php?url=listTeacher';
    echo 'Vui long chon chuc nang...';
}
$method = $_SERVER['REQUEST_METHOD'];
$router->handleRoute($url, $method);
?>


